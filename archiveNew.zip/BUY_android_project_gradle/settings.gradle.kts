
rootProject.name = "BuyVipApp"
include(":app")
