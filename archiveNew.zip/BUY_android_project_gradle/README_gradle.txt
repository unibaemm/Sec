
⚠️ Lưu ý: File gradle-wrapper.jar chỉ là placeholder (rỗng) do giới hạn môi trường này.
Khi bạn mở project trong Android Studio hoặc chạy GitHub Actions, Gradle sẽ tự động tải bản chính thức về.

Bạn không cần lo — chỉ cần giữ nguyên cấu trúc thư mục `gradle/wrapper`.
